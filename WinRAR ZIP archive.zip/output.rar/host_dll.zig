// Generated using https://github.com/a2x/cs2-dumper
// 2026-10-02 18:00:30.282421200 UTC

pub const cs2_dumper = struct {
    pub const schemas = struct {
        // Module: host.dll
        // Class count: 2
        // Enum count: 0
        pub const host_dll = struct {
            // Parent: None
            // Field count: 1
            pub const EmptyTestScript = struct {
                pub const m_hTest: usize = 0x10; // CAnimScriptParam<float32>
            };
            // Parent: None
            // Field count: 1
            pub const CAnimScriptBase = struct {
                pub const m_bIsValid: usize = 0x8; // bool
            };
        };
    };
};
